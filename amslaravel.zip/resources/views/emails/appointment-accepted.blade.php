<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Appointment Accepted</title>
</head>
<body>
    <p>Dear <strong>{{ $patientName }}</strong>,</p>
    <p>Your appointment (ID: <strong>{{ $appointmentId }}</strong>) has been <strong>accepted</strong>.</p>
    <p>Thank you,<br>PRIMA UNIMAS Health Center</p>
</body>
</html>
